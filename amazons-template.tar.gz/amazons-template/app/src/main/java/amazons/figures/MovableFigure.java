package amazons.figures;

import amazons.board.Board;
import amazons.board.Position;
import amazons.player.PlayerID;

import java.util.List;

public abstract  class MovableFigure implements Figure{
    private Position position;

    abstract  public List<Position> getAccessiblePositions(Board board);

    public Position getPosition() {
        return position;
    }
}
