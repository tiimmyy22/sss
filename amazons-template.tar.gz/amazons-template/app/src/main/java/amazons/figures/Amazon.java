package amazons.figures;

import amazons.board.Board;
import amazons.board.Position;
import amazons.player.PlayerID;
import amazons.board.CardinalDirection;
import amazons.IllegalMoveException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Amazon extends MovableFigure  implements Figure, Serializable {
    private Position position;
    private final PlayerID playerID;


    @Override
    public Position getPosition() {
        return position;
    }

    public Amazon(Position position, PlayerID playerId) {
        this.position = position;
        this.playerID = playerId;

    }


    @Override
    public boolean canMoveTo(Position newPosition, Board board) {
        if(board.isOutOfBoard(newPosition))return false;
        if (board.isEmpty(newPosition))return false;
        List<Position> accessiblePasition=getAccessiblePositions(board);
        return  accessiblePasition.contains(newPosition);
    }

    @Override
    public void moveTo(Position newPosition, Board board) throws IllegalMoveException {
        if (!board.isOutOfBoard(position)) {
            board.setFigure(position, EmptyFigure.EMPTY_FIGURE);
        }

        if (canMoveTo(newPosition, board)) {
            position = newPosition;
            board.setFigure(position, this);
        } else {
            throw new IllegalMoveException("Illegal move for Amazon at position: " + position);
        }
    }

    @Override
    public void setPosition(Position position) {
        this.position = position;
    }

    @Override
    public PlayerID getPlayerID() {
        return playerID;
    }

    public List<Position> getAccessiblePositions(Board board) {
        List<Position> accessiblePositions = new ArrayList<>();

        for (CardinalDirection direction : CardinalDirection.values()) {
            Position nextPosition = position.next(direction);

            while (!board.isOutOfBoard(nextPosition) && board.isEmpty(nextPosition)) {
                accessiblePositions.add(nextPosition);
                nextPosition = nextPosition.next(direction);
            }
        }

        return accessiblePositions;
    }
}

