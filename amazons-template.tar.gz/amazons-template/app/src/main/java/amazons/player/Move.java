package amazons.player;

import amazons.board.Position;

import java.util.Objects;

public class Move {

    public static final Move DUMMY_MOVE = new Move();

    private final Position amazonStartPosition;
    private final Position amazonDstPosition;
    private final Position arrowDestPosition;

    public Position getAmazonStartPosition() {
        return amazonStartPosition;
    }

    public Position getAmazonDstPosition() {
        return amazonDstPosition;
    }

    public Position getArrowDestPosition() {
        return arrowDestPosition;
    }

    private Move() {
        this.amazonStartPosition = null;
        this.amazonDstPosition = null;
        this.arrowDestPosition = null;
    }

    public Move(Position amazonStartPosition, Position amazonDstPosition, Position arrowDestPosition) {
        this.amazonStartPosition = amazonStartPosition;
        this.amazonDstPosition = amazonDstPosition;
        this.arrowDestPosition = arrowDestPosition;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Move move = (Move) o;
        return Objects.equals(amazonStartPosition, move.amazonStartPosition) &&
                Objects.equals(amazonDstPosition, move.amazonDstPosition) &&
                Objects.equals(arrowDestPosition, move.arrowDestPosition);
    }

    @Override
    public int hashCode() {
        return Objects.hash(amazonStartPosition, amazonDstPosition, arrowDestPosition);
    }

    @Override
    public String toString() {
        return amazonStartPosition.toString() + ':' + amazonDstPosition.toString() + "->" + arrowDestPosition.toString();
    }

}
