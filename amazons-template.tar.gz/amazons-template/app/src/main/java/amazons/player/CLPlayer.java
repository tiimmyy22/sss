package amazons.player;

import amazons.board.Position;

import java.util.List;
import java.util.Scanner;

public class CLPlayer implements Player {
    private PlayerID playerID;
    private final static Scanner inputScanner = new Scanner(System.in);
    private int boardWidth;
    private int boardHeight;

    private List<Position>[] initialPositions;

    public int getBoardWidth() {
        return boardWidth;
    }

    public int getBoardHeight() {
        return boardHeight;
    }
    @Override
    public boolean isGUIControlled() {
        return false;
    }

    @Override
    public Move play(Move opponentMove) {
        // Saisie des coordonnées de l'amazone à déplacer
        System.out.println(playerID + " sélectionnez l'amazone à déplacer (entrez les coordonnées X Y) :");
        Position amazonStartPosition = readPositionFromUser();

        // Saisie des coordonnées de la destination de l'amazone
        System.out.println(playerID + " sélectionnez la destination de l'amazone (entrez les coordonnées X Y) :");
        Position amazonDstPosition = readPositionFromUser();

        // Saisie des coordonnées de la destination de la flèche
        System.out.println(playerID + " où tirer la flèche ? (entrez les coordonnées X Y) :");
        Position arrowDstPosition = readPositionFromUser();

        // Création et retour du mouvement
        return new Move(amazonStartPosition, amazonDstPosition, arrowDstPosition);
    }

    @Override
    public void initialize(int boardWidth, int boardHeight, PlayerID playerID, List<Position>[] initialPositions) {
        this.playerID = playerID;

    }

    @Override
    public PlayerID getPlayerID() {
        return playerID;
    }

    // Méthode pour lire les coordonnées depuis l'entrée utilisateur
    private Position readPositionFromUser() {
        int x = inputScanner.nextInt();
        int y = inputScanner.nextInt();
        return new Position(x, y);
    }
}
