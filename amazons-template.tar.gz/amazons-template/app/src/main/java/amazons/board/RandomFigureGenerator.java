package amazons.board;

import amazons.figures.EmptyFigure;
import amazons.figures.Figure;

import amazons.figures.MovableFigure;
import amazons.figures.*;
import amazons.util.RandomUtil;

import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class RandomFigureGenerator implements FigureGenerator {

    private final Random random;
    private final List<MovableFigure> figures;
    private final Iterator<Position> positionIterator;

    public RandomFigureGenerator(Random random, List<MovableFigure> figures, Iterator<Position> positionIterator) {
        this.random = random;
        this.figures = figures;
        this.positionIterator = positionIterator;
    }

    @Override
    public Figure nextFigure(Position position) {
        if (random.nextBoolean() && positionIterator.hasNext()) {
            Position randomPosition = positionIterator.next();
            MovableFigure randomFigure = getRandomFigure();
            randomFigure.setPosition(randomPosition);
            return randomFigure;
        } else {
            return EmptyFigure.EMPTY_FIGURE;
        }
    }

    private MovableFigure getRandomFigure() {
        int randomIndex = random.nextInt(figures.size());
        return figures.get(randomIndex);
    }
}
