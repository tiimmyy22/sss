package amazons.board;

import javafx.scene.input.DataFormat;

import java.io.Serializable;
import java.util.Objects;


public class Position implements Serializable {
    public static final DataFormat POSITION_FORMAT = new DataFormat("amazons.position");

   int x;
   int y;
    public Position(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }


    public boolean isOutOfBounds(int numberOfColumns, int numberOfRows){
        return x < 0 || x >= numberOfColumns || y < 0 || y >= numberOfRows;
    }


    public Position next(CardinalDirection direction) {
        return new Position(x+direction.deltaColumn,y+direction.deltaRow);
    }
    public String toString() {
        return "(" + x + "," + y + ")";
    }
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || !(obj instanceof Position)) return false;
        Position position = (Position) obj;
        return x == position.x && y == position.y;
    }
    public CardinalDirection getDirection(Position destPosition){
        return CardinalDirection.getDirection(x,y, destPosition.x, destPosition.y);
    }
    public int hashCode() {
        return Objects.hash(x, y);
    }

}
