package amazons.board;

import amazons.figures.*;
import amazons.IllegalMoveException;
import java.util.HashMap;
import java.util.Map;

public abstract class MapBoard implements Board {

    private final int numberOfColumns;
    private final int numberOfRows;
    private final Map<Position, Figure> boardMap;

    public MapBoard(int numberOfColumns, int numberOfRows) {
        this.numberOfColumns = numberOfColumns;
        this.numberOfRows = numberOfRows;
        this.boardMap = new HashMap<>();
        fill(new EmptyFigureGenerator());
    }

    @Override
    public void setFigure(Position position, Figure figure) {
            boardMap.put(position, figure);

    }

    @Override
    public Figure getFigure(Position position) {
        return boardMap.getOrDefault(position, EmptyFigure.EMPTY_FIGURE);
    }

    @Override
    public boolean isEmpty(Position position) {
        return getFigure(position) == EmptyFigure.EMPTY_FIGURE;
    }

    @Override
    public boolean isOutOfBoard(Position position) {
        return position.isOutOfBounds(numberOfColumns, numberOfRows);
    }

    @Override
    public void moveFigure(Position startPosition, Position dstPosition) throws IllegalMoveException {
        Figure figureToMove = getFigure(startPosition);
        if (figureToMove == null || !figureToMove.canMoveTo(dstPosition, this)) {
            throw new IllegalMoveException("Illegal move");
        }

        setFigure(dstPosition, figureToMove);
        setFigure(startPosition, EmptyFigure.EMPTY_FIGURE);
        figureToMove.setPosition(dstPosition);
    }

    @Override
    public void shootArrow(Position startPosition, Position arrowDstPosition) throws IllegalMoveException {
        Figure arrow = new ArrowFigure();
        setFigure(arrowDstPosition, arrow);
    }
    @Override
    public void fill(FigureGenerator generator) {
        for (int x = 0; x < numberOfColumns; x++) {
            for (int y = 0; y < numberOfRows; y++) {
                Position position = new Position(x, y);
                Figure figure = generator.nextFigure(position);
                setFigure(position, figure);
            }
        }
    }

}
