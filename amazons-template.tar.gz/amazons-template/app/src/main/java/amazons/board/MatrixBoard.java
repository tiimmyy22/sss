package amazons.board;
import amazons.figures.Amazon;
import amazons.figures.ArrowFigure;
import amazons.figures.EmptyFigure;
import amazons.figures.*;
import amazons.IllegalMoveException;
import amazons.player.PlayerID;
import amazons.figures.MovableFigure;
import java.util.Random;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;


public class MatrixBoard implements Board {

    public int getNumberOfColumns() {
        return numberOfColumns;
    }

    public int getNumberOfRows() {
        return numberOfRows;
    }

    private final int numberOfColumns;
    private final int numberOfRows;
    private final Figure[][] board;


    public MatrixBoard(int numberOfColumns, int numberOfRows) {
        this.numberOfColumns = numberOfColumns;
        this.numberOfRows = numberOfRows;
        this.board = new Figure[numberOfColumns][numberOfRows];
        fill(new EmptyFigureGenerator());
    }

    @Override
    public void setFigure(Position position, Figure figure) {
            board[position.getX()][position.getY()] = figure;

    }

    @Override
    public Figure getFigure(Position position) {
        if (!isOutOfBoard(position)) {
            return board[position.getX()][position.getY()];
        }
        return null; // SINON ON PEUT FAIRE UNE EXPTION
    }

    @Override
    public boolean isEmpty(Position position) {
        return getFigure(position) instanceof EmptyFigure;
    }

    @Override
    public boolean isOutOfBoard(Position position) {
        int x = position.getX();
        int y = position.getY();
        return x < 0 || x >= numberOfColumns || y < 0 || y >= numberOfRows;
    }

    public void moveFigure(Position startPosition, Position dstPosition) throws IllegalMoveException {
        Figure figureToMove = getFigure(startPosition);

        if (figureToMove == null || figureToMove instanceof EmptyFigure) {
            throw new IllegalMoveException("No figure to move at the starting position.");
        }

        // Utilisez la méthode canMoveTo de la figure pour vérifier le mouvement
        if (!figureToMove.canMoveTo(dstPosition, this)) {
            throw new IllegalMoveException("Illegal move for the figure.");
        }

        // Utilisez setFigure pour déplacer la figure
        setFigure(startPosition, EmptyFigure.EMPTY_FIGURE);
        setFigure(dstPosition, figureToMove);

        // La position de la figure devrait être mise à jour par la méthode canMoveTo
        // figureToMove.setPosition(dstPosition);
    }


    public void shootArrow(Position startPosition, Position arrowDstPosition) throws IllegalMoveException {
        Figure arrow = getFigure(startPosition);

        if (arrow == null || !(arrow instanceof ArrowFigure)) {
            throw new IllegalMoveException("No arrow to shoot at the starting position.");
        }

        if (!arrow.canMoveTo(arrowDstPosition, this)) {
            throw new IllegalMoveException("Illegal arrow shot.");
        }

        setFigure(arrowDstPosition, ArrowFigure.ARROW_FIGURE);
    }

    public void fill(FigureGenerator generator) {
        for (int x = 0; x < numberOfColumns; x++) {
            for (int y = 0; y < numberOfRows; y++) {
                setFigure(new Position(x, y), generator.nextFigure(new Position(x, y)));
            }
        }
    }

    @Override
    public MatrixIterator<Figure> iterator() {
        return new MatrixIterator<>(numberOfRows, numberOfColumns, board);
    }

    public Iterator<Position> positionIterator() {
        return new PositionIterator(numberOfColumns, numberOfRows);
    }

    @Override
    public String toString(){
        String result = "";
        int numJ=-1;

        result += "+";
        for (int col = 0; col < numberOfColumns; col++) {
            result += "----+";
        }
        result += "\n";

        for (int row = 0; row < numberOfRows; row++) {
            result += "| ";
            for (int col = 0; col < numberOfColumns; col++) {
                Figure figure = getFigure(new Position(col,row));
                if (figure instanceof Amazon) {
                    Amazon amazon = (Amazon) figure;
                    if (amazon.getPlayerID()== PlayerID.PLAYER_ZERO)
                    {
                        numJ=0;
                    }
                    if (amazon.getPlayerID()==PlayerID.PLAYER_ONE)
                    {
                        numJ=1;
                    }
                    result += "A" + String.valueOf(numJ) + " | ";
                } else if (figure instanceof ArrowFigure) {
                    result += "XX | ";
                } else {
                    result += "   | ";
                }
            }
            result += row + "\n";

            result += "+";
            for (int col = 0; col < numberOfColumns; col++) {
                result += "----+";
            }
            result += "\n";
        }
        result += "  ";
        for (int col = 0; col < numberOfColumns; col++) {
            result += col + "    ";
        }
        result += "     ";
        result = result.trim(); // Supprimer les espaces à la fin de la chaîne
        result +="  ";
        return result;
    }


}




















